Am facut taskurile 1-4

In fisierul task3_4 am facut graficele 1 si 2.

In fisierul get_features , mai intai calculez filtrele si le salvez in variabila filters si cele inversate in filters_inverted. Am luat in matricea ferestre audioul din k in k secvente pentru cele F esantioane, dupa care am inmultito cu filtrele inversate.

In fisierul get_equal_bark mai intai am facut vectorul echidistant s prin linspace de la 0 si fs/2 in scala bark si dupa in freqs am transformat s.

