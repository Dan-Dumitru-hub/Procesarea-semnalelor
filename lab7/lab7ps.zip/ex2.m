  load('notes_signal.mat');

  #figure;
  #coef=fft(notes_signal);
  
  plot(notes_signal);
  
  coef = fft(notes_signal);
  N = length(coef);
  x = fs / N * linspace(-N/2, N/2, N);

  figure;
  stem(x, abs(fftshift(coef)));

  notes_signal = hamming(length(notes_signal))' .* notes_signal;

  figure;
  plot(notes_signal);

  coef1 = fft(notes_signal);
  N = length(coef1);
  x = fs / N * linspace(-N/2, N/2, N);

  figure;
  stem(x, abs(fftshift(coef1)));

